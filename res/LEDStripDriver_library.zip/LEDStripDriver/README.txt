//***********************************************************************
//
// Name:LEDStripDriver liararies v0.9b for Grove - LED Strip Driver v0.9b
// Author:Frankie.Chu at Seeed Studio.
// Date:March 9,2012
// Version:0.9b
// Software platform:Arduino-1.0
// Hardware platform:Arduino UNO/Seeeduino/Arduino Mega +
//                   Grove - LED Strip Driver v0.9b
// Demo code:
//   DualLEDStrip:Light the two LED strips with two driver.
//   SingleLEDStrip:Light the single LED strip.
//   DemoForWhiteLEDStrip:Light the White LED Flexi-Strip.
//		 Default:"-"pin of it is connected to "B" of the driver.
//
//***********************************************************************